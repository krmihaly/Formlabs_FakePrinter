#include "Fakeprinter.h"

#include <filesystem>
#include <iostream>
#include <curl/curl.h>


FakePrinter::FakePrinter(const std::string& name, Mode mode) : m_name(name), m_mode(mode) {}



void FakePrinter::print(const std::string& output_folder) {
    std::cout << output_folder << std::endl;
}

std::vector<std::string> splitCsv(const std::string& line) {
    std::vector<std::string> result;
    std::stringstream ss(line);
    std::string item;

    while (std::getline(ss, item, ',')) {
        // Remove leading and trailing whitespace
        item.erase(0, item.find_first_not_of(" \t"));
        item.erase(item.find_last_not_of(" \t") + 1);

        // Remove quotes if present
        if (item.front() == '"' && item.back() == '"') {
            item = item.substr(1, item.length() - 2);
        }

        result.push_back(item);
    }

    return result;
}

void FakePrinter::readCsvData(const std::string& filename) {
     std::ifstream file(filename);
    if (!file) {
        throw std::runtime_error("Unable to open CSV file: " + filename);
    }

    std::string line;
    // Skip header
    std::getline(file, line);

    while (std::getline(file, line)) {
        auto values = splitCsv(line);
        try {
            m_layers.emplace_back(values);
        } catch (const std::exception& e) {
            std::cerr << "Error parsing line: " << line << "\n";
            std::cerr << "Error message: " << e.what() << "\n";
            // Decide whether to skip this line or throw an exception
        }
    }

    for (const auto& layer : m_layers) {
        writeLayerToFileSystem(layer);
    }
 
}





void FakePrinter::writeLayerToFileSystem(const PrintLayer& layer)  {
    std::filesystem::create_directory(m_name);
    std::string folderName = m_name + "\\" + "Layer_" + std::to_string(layer.getLayerNumber());
    std::filesystem::create_directory(folderName);
    downloadImage(layer.getImageUrl(), folderName + "\\" + layer.getFileName());
    layer.writeToFile(folderName + "\\Layer_" + std::to_string(layer.getLayerNumber()) + ".txt");
}

bool FakePrinter::downloadImage(const std::string& url, const std::string& filename) {
    CURL* curl;
    FILE* fp;
    CURLcode res;
    curl = curl_easy_init();
    if (curl) {
        fopen_s(&fp, filename.c_str(), "wb");
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, NULL);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);
        res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);
        fclose(fp);
        return (res == CURLE_OK);
    }
    return false;
}
