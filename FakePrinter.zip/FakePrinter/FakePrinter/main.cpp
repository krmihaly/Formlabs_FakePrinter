#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Fakeprinter.h"
#include <string>

int main(int argc, char* argv[]) {
    bool is_automatic=false;
    std::string output_filename;
     if (argc <5) {
        std::cerr << "Usage: " << argv[0] << " <name:print1> <input:in_file.csv> <output:output_folder> <mode:supervised|automatic> "  << std::endl ;
        return 1;
    }
    std::string arg_print_name=argv[1];
    std::string arg_input_filename = argv[2];
    std::string arg_output_folder = argv[3];
    std::string arg_mode = argv[4];
    Mode mode;
    if (arg_mode == "automatic") {
        mode =  Mode::Automatic;
    } else if (arg_mode == "supervised") {
        mode =  Mode::Supervised;
    } else {
        std::cerr << "Invalid mode" << std::endl;
        return 1;
    }

    FakePrinter printer(arg_print_name, mode);
    printer.readCsvData(arg_input_filename);
    printer.print(arg_output_folder);

    return 0;
}