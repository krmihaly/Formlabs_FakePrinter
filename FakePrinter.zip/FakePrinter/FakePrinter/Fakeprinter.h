#include <string>
#include "PrintLayer.h"
#include <map>

enum class Mode {
    Supervised,
    Automatic
};

class FakePrinter{

    public:
     FakePrinter(const std::string& name, Mode mode );
     void print(const std::string& outputFolder);
     void readCsvData(const std::string& filename);
     
    private:
     std::string m_name;
     Mode m_mode;
     std::vector<PrintLayer> m_layers;
     void writeLayerToFileSystem(const PrintLayer& layer) ;
     bool downloadImage(const std::string& url, const std::string& filename);
};
