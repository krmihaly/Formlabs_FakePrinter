#include <vector>
#include <string>
#include <sstream>
#include <filesystem>
#include <fstream>

class PrintLayer {
public:
    PrintLayer(const std::vector<std::string>& data) {
        if (data.size() != 18) {
            throw std::invalid_argument("Invalid number of fields for PrintLayer");
        }

        layerError = data[0];
        layerNumber = std::stoi(data[1]);
        layerHeight = std::stod(data[2]);
        materialType = data[3];
        extrusionTemperature = std::stoi(data[4]);
        printSpeed = std::stoi(data[5]);
        layerAdhesionQuality = data[6];
        infillDensity = std::stoi(data[7]);
        infillPattern = data[8];
        shellThickness = std::stoi(data[9]);
        overhangAngle = std::stoi(data[10]);
        coolingFanSpeed = std::stoi(data[11]);
        retractionSettings = data[12];
        zOffsetAdjustment = std::stod(data[13]);
        printBedTemperature = std::stoi(data[14]);
        layerTime = data[15];
        fileName = data[16];
        imageUrl = data[17];
    }

    // Getter methods
    std::string getLayerError() const { return layerError; }
    int getLayerNumber() const { return layerNumber; }
    double getLayerHeight() const { return layerHeight; }
    std::string getMaterialType() const { return materialType; }
    int getExtrusionTemperature() const { return extrusionTemperature; }
    int getPrintSpeed() const { return printSpeed; }
    std::string getLayerAdhesionQuality() const { return layerAdhesionQuality; }
    int getInfillDensity() const { return infillDensity; }
    std::string getInfillPattern() const { return infillPattern; }
    int getShellThickness() const { return shellThickness; }
    int getOverhangAngle() const { return overhangAngle; }
    int getCoolingFanSpeed() const { return coolingFanSpeed; }
    std::string getRetractionSettings() const { return retractionSettings; }
    double getZOffsetAdjustment() const { return zOffsetAdjustment; }
    int getPrintBedTemperature() const { return printBedTemperature; }
    std::string getLayerTime() const { return layerTime; }
    const std::string getFileName() const { return fileName; }
    const std::string getImageUrl() const { return imageUrl; }

    // Method to write layer data to a file
    void writeToFile(const std::string& path) const {
        std::ofstream file(path);
        if (!file) {
            throw std::runtime_error("Unable to open file for writing: " + path);
        }

        file << "Layer Error: " << layerError << "\n"
             << "Layer Number: " << layerNumber << "\n"
             << "Layer Height: " << layerHeight << "\n"
             << "Material Type: " << materialType << "\n"
             << "Extrusion Temperature: " << extrusionTemperature << "\n"
             << "Print Speed: " << printSpeed << "\n"
             << "Layer Adhesion Quality: " << layerAdhesionQuality << "\n"
             << "Infill Density: " << infillDensity << "\n"
             << "Infill Pattern: " << infillPattern << "\n"
             << "Shell Thickness: " << shellThickness << "\n"
             << "Overhang Angle: " << overhangAngle << "\n"
             << "Cooling Fan Speed: " << coolingFanSpeed << "\n"
             << "Retraction Settings: " << retractionSettings << "\n"
             << "Z-Offset Adjustment: " << zOffsetAdjustment << "\n"
             << "Print Bed Temperature: " << printBedTemperature << "\n"
             << "Layer Time: " << layerTime << "\n"
             << "File Name: " << fileName << "\n"
             << "Image URL: " << imageUrl << "\n";
    }

private:
    std::string layerError;
    int layerNumber;
    double layerHeight;
    std::string materialType;
    int extrusionTemperature;
    int printSpeed;
    std::string layerAdhesionQuality;
    int infillDensity;
    std::string infillPattern;
    int shellThickness;
    int overhangAngle;
    int coolingFanSpeed;
    std::string retractionSettings;
    double zOffsetAdjustment;
    int printBedTemperature;
    std::string layerTime;
    std::string fileName;
    std::string imageUrl;
};